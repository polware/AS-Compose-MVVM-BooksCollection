package com.polware.bookcollection.ui.components

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.material.Card
import androidx.compose.material.MaterialTheme
import androidx.compose.material.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.RectangleShape
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import coil.compose.AsyncImage
import com.polware.bookcollection.data.firebase.FirestoreBook
import com.polware.bookcollection.data.models.Item
import com.polware.bookcollection.ui.navigation.ScreenRoutes

@Composable
fun BookItem(book: Item, navController: NavController) {
    val imageUrl = book.volumeInfo.imageLinks?.smallThumbnail

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .height(160.dp)
            .padding(4.dp)
            .clickable {
                navController.navigate(ScreenRoutes.BookDetailsScreen.name + "/${book.id}")
            },
        shape = RectangleShape,
        elevation = 6.dp
    ) {
        Row(
            modifier = Modifier.padding(5.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            AsyncImage(
                model = imageUrl,
                contentScale = ContentScale.Crop,
                contentDescription = "Book image",
                modifier = Modifier
                    .width(160.dp)
                    .fillMaxHeight()
                    .padding(8.dp)
            )
            Column {
                Text(
                    text = book.volumeInfo.title,
                    overflow = TextOverflow.Ellipsis,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    text = "Author(s): ${book.volumeInfo.authors}",
                    overflow = TextOverflow.Clip,
                    style = MaterialTheme.typography.subtitle1
                )
                Text(
                    text = "Date: ${book.volumeInfo.publishedDate}",
                    overflow = TextOverflow.Clip,
                    style = TextStyle(fontStyle = FontStyle.Italic)
                )
                Text(
                    text = "Category: ${book.volumeInfo.categories}",
                    overflow = TextOverflow.Clip,
                    style = TextStyle(fontStyle = FontStyle.Italic)
                )
            }
        }
    }
}