package com.polware.bookcollection.ui.navigation

import android.os.Build
import android.util.Log
import android.widget.Toast
import androidx.annotation.RequiresApi
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import com.google.firebase.Timestamp
import com.google.firebase.firestore.FirebaseFirestore
import com.polware.bookcollection.R
import com.polware.bookcollection.data.firebase.FirestoreBook
import com.polware.bookcollection.data.utils.formatDate
import com.polware.bookcollection.ui.components.*
import com.polware.bookcollection.viewmodel.HomeViewModel

@RequiresApi(Build.VERSION_CODES.N)
@Composable
fun BookUpdateScreen(navController: NavController,
                     bookDatabaseId: String, homeViewModel: HomeViewModel) {

    val booksCollection = homeViewModel.fireStoreData.value.data
    val filteredBooks = booksCollection!!.toList().filter {
        it.googleBookId == bookDatabaseId
    }
    Log.i("FoundBooks", "List: $booksCollection")
    var bookItem: FirestoreBook? = null
    var bookNotes = ""
    var rating: Int? = null
    filteredBooks.forEach {
        bookItem = it
        bookNotes = if (it.notes.toString().isNotEmpty()) it.notes.toString() else "Add a note..."
        rating = it.rating?.toInt()
    }
    val addedNotes = remember {
        mutableStateOf("")
    }
    val isStartedReading = remember {
        mutableStateOf(false)
    }
    val isFinishedReading = remember {
        mutableStateOf(false)
    }
    val ratingValue = remember {
        mutableStateOf(0)
    }
    val context = LocalContext.current

    Scaffold(
        topBar = {
            MainAppBar(
                title = "Update Book",
                icon = Icons.Default.ArrowBack,
                showProfile = false,
                navController = navController
            ) {
                navController.popBackStack()
            }
        }
    ) {
        Surface(
            modifier = Modifier
                .fillMaxSize()
                .padding(3.dp)
        ) {
            Column(
                modifier = Modifier.padding(top = 3.dp),
                verticalArrangement = Arrangement.Top,
                horizontalAlignment = Alignment.CenterHorizontally
            ) {

                Surface(
                    modifier = Modifier
                        .padding(2.dp)
                        .fillMaxWidth(),
                    shape = CircleShape,
                    elevation = 5.dp
                ) {
                    Row {
                        Spacer(modifier = Modifier.width(30.dp))
                        Column(
                            modifier = Modifier.padding(4.dp),
                            verticalArrangement = Arrangement.Center
                        ) {
                            CardBookDetail(bookItem) { }
                        }
                    }
                }
                Spacer(modifier = Modifier.height(20.dp))
                // Body
                Column {
                    BookNotesUpdate(notes = bookNotes) {
                        note ->
                        addedNotes.value = note
                    }
                    // Buttons about reading
                    Row(
                        modifier = Modifier
                            .padding(4.dp)
                            .fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceEvenly
                    ) {
                        TextButton(
                            onClick = {
                                isStartedReading.value = true
                                },
                            enabled = bookItem?.startedReading == null
                        ) {
                            if (bookItem?.startedReading == null) {
                                if (!isStartedReading.value) {
                                    Text(
                                        text = "Start reading",
                                        color = Color(0xFF005b96)
                                    )
                                }
                                else {
                                    Text(
                                        text = "Reading started!",
                                        modifier = Modifier.alpha(0.7f),
                                        color = Color(0xFF008744)
                                    )
                                }
                            }
                            else {
                                Text(
                                    text = "Started on: ${formatDate(bookItem?.startedReading!!)}"
                                )
                            }

                        }
                        TextButton(
                            onClick = {
                                isFinishedReading.value = true
                                },
                            enabled = bookItem?.finishedReading == null
                        ) {
                            if (bookItem?.finishedReading == null) {
                                if (!isFinishedReading.value) {
                                    Text(
                                        text = "Mark as read",
                                        color = Color(0xFF005b96)
                                    )
                                }
                                else {
                                    Text(
                                        text = "Finished reading!",
                                        color = Color(0xFF008744)
                                    )
                                }
                            }
                            else {
                                Text(text = "Finished on: ${formatDate(bookItem?.finishedReading!!)}")
                            }
                        }
                    }
                    // Rating bar
                    rating?.let {
                            value ->
                            BookRatingBar(rating = value) {
                                rating ->
                                ratingValue.value = rating
                            }
                    }
                    // Buttons
                    Row(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(top = 20.dp),
                        horizontalArrangement = Arrangement.SpaceEvenly
                    ) {
                        val editedNote = bookItem?.notes != addedNotes.value
                        val editedRating = rating != ratingValue.value
                        val isFinishedTimeStamp = if (isFinishedReading.value) Timestamp.now()
                        else bookItem?.finishedReading
                        val isStartedTimeStamp = if (isStartedReading.value) Timestamp.now()
                        else bookItem?.startedReading
                        val bookUpdateStatus = editedNote || editedRating || isStartedReading.value
                                || isFinishedReading.value

                        val bookToUpdate = hashMapOf(
                            "finished_reading_at" to isFinishedTimeStamp,
                            "started_reading_at" to isStartedTimeStamp,
                            "rating" to ratingValue.value,
                            "notes" to addedNotes.value
                        ).toMap()
                        RoundedButton(label = "Update", radius = 50) {
                            if (bookUpdateStatus) {
                                FirebaseFirestore.getInstance()
                                    .collection("books")
                                    .document(bookItem?.id!!)
                                    .update(bookToUpdate)
                                    .addOnCompleteListener {
                                        Toast.makeText(context, "Book Updated Successfully!",
                                            Toast.LENGTH_SHORT).show()
                                        navController.navigate(ScreenRoutes.HomeScreen.name)
                                        // Log.d("Update", "ShowSimpleForm: ${task.result.toString()}")
                                    }.addOnFailureListener{
                                        Log.e("BookUpdate", "Error updating document" , it)
                                    }
                            }
                        }
                        val openDialog = remember {
                            mutableStateOf(false)
                        }
                        if (openDialog.value) {
                            ShowAlertDialog(message = stringResource(id = R.string.warning) + "\n" +
                                    stringResource(id = R.string.action), openDialog = openDialog) {
                                FirebaseFirestore.getInstance()
                                    .collection("books")
                                    .document(bookItem?.id!!)
                                    .delete()
                                    .addOnCompleteListener {
                                        if (it.isSuccessful) {
                                            openDialog.value = false
                                            Toast.makeText(context, "Book deleted!",
                                                Toast.LENGTH_SHORT).show()
                                            navController.navigate(ScreenRoutes.HomeScreen.name)
                                        }
                                    }
                            }
                        }
                        RoundedButton(label = "Delete", radius = 50) {
                            openDialog.value = true
                        }
                    }
                }
            }
        }
    }
}
