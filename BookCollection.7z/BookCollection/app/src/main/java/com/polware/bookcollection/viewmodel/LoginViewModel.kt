package com.polware.bookcollection.viewmodel

import android.util.Log
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.ktx.auth
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.ktx.Firebase
import com.polware.bookcollection.data.firebase.FirestoreUser
import kotlinx.coroutines.launch

class LoginViewModel: ViewModel() {
    //val loadingState = MutableStateFlow(LoadingState.IDLE)
    private val auth: FirebaseAuth = Firebase.auth
    private val _loading = MutableLiveData(false)
    val loading: LiveData<Boolean> = _loading

    fun createUser(email: String, password: String, homeScreen: () -> Unit) {
        if (_loading.value == false) {
            _loading.value = true
            auth.createUserWithEmailAndPassword(email, password)
                .addOnCompleteListener {
                    task ->
                    if (task.isSuccessful) {
                        val displayName = task.result.user?.email?.split("@")?.get(0)
                        addUserToFirestore(displayName)
                        homeScreen()
                    }
                    else {
                        Log.e("SignUp Error", "${task.result}")
                    }
                    _loading.value = false
                }.addOnFailureListener {
                    e ->
                    Log.e("SignUpException", "${e.message}")
                }
        }
    }

    private fun addUserToFirestore(displayName: String?) {
        val userId = auth.currentUser?.uid
        val user = FirestoreUser(userId = userId.toString(), displayName = displayName.toString(),
            avatarUrl = "", quote = "Just testing", profession = "Android developer", id = null).dataToMap()
        FirebaseFirestore.getInstance().collection("users").add(user)
    }

    fun signIn(email: String, password: String, homeScreen: () -> Unit) = viewModelScope.launch {
        try {
            auth.signInWithEmailAndPassword(email, password)
                .addOnCompleteListener {
                    task ->
                    if (task.isSuccessful) {
                        homeScreen()
                    }
                    else {
                        Log.e("LoginError", task.result.toString())
                    }
                }
        } catch (exception: Exception) {
            Log.e("LoginException", "${exception.message}")
        }
    }

}