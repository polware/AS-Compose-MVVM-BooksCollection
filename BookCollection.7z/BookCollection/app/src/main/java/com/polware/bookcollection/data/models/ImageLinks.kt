package com.polware.bookcollection.data.models

data class ImageLinks(
    val smallThumbnail: String,
    val thumbnail: String
)