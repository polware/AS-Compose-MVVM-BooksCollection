package com.polware.bookcollection.di

import com.google.firebase.firestore.FirebaseFirestore
import com.polware.bookcollection.data.api.GoogleApi
import com.polware.bookcollection.data.utils.Constants
import com.polware.bookcollection.viewmodel.BookRepository
import com.polware.bookcollection.viewmodel.FirestoreRepository
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.components.SingletonComponent
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import javax.inject.Singleton

@InstallIn(SingletonComponent::class)
@Module
object AppModules {

    @Singleton
    @Provides
    fun provideGoogleApi(): GoogleApi {
        return Retrofit.Builder()
            .baseUrl(Constants.BASE_URL)
            .addConverterFactory(GsonConverterFactory.create())
            .build()
            .create(GoogleApi::class.java)
    }

    @Singleton
    @Provides
    fun provideBookRepository(googleApi: GoogleApi) = BookRepository(googleApi)

    @Singleton
    @Provides
    fun provideFirestoreRepository() = FirestoreRepository(queryBook = FirebaseFirestore
        .getInstance().collection("books"))

}