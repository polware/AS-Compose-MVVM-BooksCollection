package com.polware.bookcollection.ui.navigation

enum class ScreenRoutes {
    SplashScreen,
    LoginScreen,
    SignUpScreen,
    HomeScreen,
    SearchScreen,
    BookDetailsScreen,
    BookUpdateScreen,
    ProfileStatsScreen;

    companion object {
        fun fromRoute(route: String): ScreenRoutes = when (route.substringBefore("/")) {
            SplashScreen.name -> SplashScreen
            LoginScreen.name -> LoginScreen
            SignUpScreen.name -> SignUpScreen
            HomeScreen.name -> HomeScreen
            SearchScreen.name -> SearchScreen
            BookDetailsScreen.name -> BookDetailsScreen
            BookUpdateScreen.name -> BookUpdateScreen
            ProfileStatsScreen.name -> ProfileStatsScreen
            else -> throw IllegalArgumentException("The route $route is not valid")
        }
    }

}