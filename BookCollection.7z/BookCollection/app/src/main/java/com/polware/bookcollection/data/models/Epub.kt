package com.polware.bookcollection.data.models

data class Epub(
    val acsTokenLink: String?,
    val isAvailable: Boolean
)