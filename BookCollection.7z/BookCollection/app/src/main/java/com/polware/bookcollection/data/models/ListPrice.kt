package com.polware.bookcollection.data.models

data class ListPrice(
    val amount: Int,
    val currencyCode: String
)