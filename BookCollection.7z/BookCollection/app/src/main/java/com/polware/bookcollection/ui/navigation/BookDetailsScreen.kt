package com.polware.bookcollection.ui.navigation

import android.util.Log
import android.widget.Toast
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.runtime.Composable
import androidx.compose.runtime.produceState
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.RectangleShape
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.core.text.HtmlCompat
import androidx.navigation.NavController
import coil.compose.AsyncImage
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore
import com.polware.bookcollection.data.api.ResponseStatus
import com.polware.bookcollection.data.firebase.FirestoreBook
import com.polware.bookcollection.data.models.Item
import com.polware.bookcollection.ui.components.MainAppBar
import com.polware.bookcollection.ui.components.RoundedButton
import com.polware.bookcollection.viewmodel.BookDetailViewModel

@Composable
fun BookDetailsScreen(navController: NavController,
                      bookId: String, bookDetailViewModel: BookDetailViewModel) {

    val book = produceState<ResponseStatus<Item>>(
        initialValue = ResponseStatus.Loading()) {
        value = bookDetailViewModel.getBookDetails(bookId = bookId)
    }.value
    val localDims = LocalContext.current.resources.displayMetrics
    val plainTextDescription = book.data?.volumeInfo?.description?.let {
        HtmlCompat.fromHtml(it, HtmlCompat.FROM_HTML_MODE_LEGACY).toString()
    }
    val context = LocalContext.current

    Scaffold(
        topBar = {
            MainAppBar(
                title = "Book details",
                icon = Icons.Default.ArrowBack,
                showProfile = false,
                navController = navController) {
                navController.popBackStack()
            }
        }
    ) {
        Surface(
            modifier = Modifier
                .padding(3.dp)
                .fillMaxSize()
        ) {
            Column(
                modifier = Modifier.padding(top = 15.dp, start = 15.dp, end = 15.dp),
                verticalArrangement = Arrangement.Top,
                horizontalAlignment = Alignment.CenterHorizontally
            ) {

                Card(
                    modifier = Modifier.padding(20.dp),
                    shape = CircleShape,
                    elevation = 5.dp
                ) {
                    AsyncImage(
                        model = book.data?.volumeInfo?.imageLinks?.thumbnail,
                        contentScale = ContentScale.Crop,
                        contentDescription = "Book image",
                        modifier = Modifier
                            .width(150.dp)
                            .height(150.dp)
                            .padding(2.dp)
                    )
                }
                Text(
                    text = book.data?.volumeInfo?.title.toString(),
                    textAlign = TextAlign.Center,
                    style = MaterialTheme.typography.h5,
                    maxLines = 2,
                    overflow = TextOverflow.Ellipsis,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    text = "Author(s): ${book.data?.volumeInfo?.authors}",
                    textAlign = TextAlign.Center,
                    maxLines = 2,
                    overflow = TextOverflow.Ellipsis,
                    style = MaterialTheme.typography.subtitle1
                )
                Text(
                    text = "Page count: ${book.data?.volumeInfo?.pageCount}",
                    overflow = TextOverflow.Clip,
                    style = MaterialTheme.typography.subtitle1
                )
                Text(
                    text = "Categories: ${book.data?.volumeInfo?.categories}",
                    textAlign = TextAlign.Center,
                    maxLines = 2,
                    overflow = TextOverflow.Ellipsis,
                    style = TextStyle(fontStyle = FontStyle.Italic)
                )
                Text(
                    text = "Published: ${book.data?.volumeInfo?.publishedDate}",
                    overflow = TextOverflow.Clip,
                    style = TextStyle(fontStyle = FontStyle.Italic)
                )
                Spacer(modifier = Modifier.height(5.dp))
                Surface(
                    modifier = Modifier
                        .height(localDims.heightPixels.dp.times(0.09f))
                        .padding(5.dp),
                    shape = RectangleShape,
                    border = BorderStroke(2.dp, color = Color(0xFF005b96))
                ) {
                    LazyColumn(modifier = Modifier.padding(10.dp)) {
                        item {
                            Text(
                                text = plainTextDescription.toString(),
                                style = MaterialTheme.typography.subtitle1,
                                textAlign = TextAlign.Justify
                            )
                        }
                    }
                }
                // Buttons
                Row(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(top = 15.dp),
                    horizontalArrangement = Arrangement.SpaceEvenly
                ) {
                    RoundedButton(label = "Save", radius = 50) {
                        val book = FirestoreBook(
                            title = book.data?.volumeInfo?.title,
                            authors = book.data?.volumeInfo?.authors?.toString(),
                            description = book.data?.volumeInfo?.description,
                            categories = book.data?.volumeInfo?.categories?.toString(),
                            notes = "",
                            imageUrl = book.data?.volumeInfo?.imageLinks?.thumbnail,
                            publishedDate = book.data?.volumeInfo?.publishedDate,
                            pageCount = book.data?.volumeInfo?.pageCount?.toString(),
                            rating = 0.0,
                            googleBookId = book.data?.id,
                            userId = FirebaseAuth.getInstance().currentUser!!.uid
                        )
                        saveToFirebase(book = book, navController = navController)
                        Toast.makeText(context, "Book saved to Database", Toast.LENGTH_SHORT).show()
                    }
                    RoundedButton(label = "Cancel", radius = 50) {
                        navController.navigate(ScreenRoutes.SearchScreen.name)
                    }
                }
            }
        }
    }

}

fun saveToFirebase(book: FirestoreBook, navController: NavController) {
    val database = FirebaseFirestore.getInstance()
    val dbCollection = database.collection("books")

    if (book.toString().isNotEmpty()) {
        dbCollection.add(book).addOnSuccessListener {
            documentRef ->
            val documentId = documentRef.id
            dbCollection.document(documentId)
                .update(hashMapOf("id" to documentId) as Map<String, Any>)
                .addOnCompleteListener {
                    task ->
                    if (task.isSuccessful) {
                        navController.navigate(ScreenRoutes.SearchScreen.name)
                    }
                }.addOnFailureListener {
                    Log.e("SaveToDatabase", "Error: $it")
                }
        }
    }
}