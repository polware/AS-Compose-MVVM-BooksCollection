package com.polware.bookcollection.viewmodel

import com.google.firebase.firestore.FirebaseFirestoreException
import com.google.firebase.firestore.Query
import com.polware.bookcollection.data.firebase.FirestoreBook
import com.polware.bookcollection.data.firebase.FirestoreResponse
import kotlinx.coroutines.tasks.await
import javax.inject.Inject

class FirestoreRepository @Inject constructor(private val queryBook: Query) {

    suspend fun getBooksFromDB(): FirestoreResponse<List<FirestoreBook>, Boolean, Exception> {
        val fireStoreResponse = FirestoreResponse<List<FirestoreBook>, Boolean, Exception>()
        try {
            fireStoreResponse.loading = true
            // Coroutine task for queryBook
            fireStoreResponse.data = queryBook.get().await().documents.map {
                documentSnapshot ->
                documentSnapshot.toObject(FirestoreBook::class.java)!!
            }
            if (!fireStoreResponse.data.isNullOrEmpty())
                fireStoreResponse.loading = false
        } catch (exception: FirebaseFirestoreException) {
            fireStoreResponse.exception = exception
        }
        return fireStoreResponse
    }

}