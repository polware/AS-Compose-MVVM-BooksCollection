package com.polware.bookcollection.ui.navigation

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AccountCircle
import androidx.compose.material.icons.filled.Add
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import com.google.firebase.auth.FirebaseAuth
import com.polware.bookcollection.data.firebase.FirestoreBook
import com.polware.bookcollection.ui.components.*
import com.polware.bookcollection.viewmodel.HomeViewModel

@Composable
fun HomeScreen(navController: NavController, homeViewModel: HomeViewModel) {
    val userName = FirebaseAuth.getInstance().currentUser?.email?.split("@")?.get(0)
    var booksList = emptyList<FirestoreBook>()
    val currentUser = FirebaseAuth.getInstance().currentUser

    if (!homeViewModel.fireStoreData.value.data.isNullOrEmpty()) {
        booksList = homeViewModel.fireStoreData.value.data?.toList()!!.filter {
            book ->
            book.userId == currentUser?.uid.toString()
        }
    }

    Scaffold(
        topBar = {
            MainAppBar(title = "Book Collection", navController = navController)
        },
        floatingActionButton = {
            FloatingActionButton(
                onClick = {
                    navController.navigate(ScreenRoutes.SearchScreen.name)
                    },
                shape = RoundedCornerShape(50.dp),
                backgroundColor = Color(0xFF005b96)
            ) {
                Icon(
                    imageVector = Icons.Default.Add,
                    contentDescription = "Add a book",
                    tint = Color.White
                )
            }
        }
    ) {
        // Main Content
        Surface(
            modifier = Modifier.fillMaxSize()
        ) {

            Column(
                modifier = Modifier.padding(2.dp),
                verticalArrangement = Arrangement.Top
            ) {
                Row(
                    modifier = Modifier.align(alignment = Alignment.Start),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    TitleSection(label = "You are currently reading:" )
                    Spacer(modifier = Modifier.fillMaxWidth(0.7f))
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Icon(
                            imageVector = Icons.Filled.AccountCircle,
                            contentDescription = "Profile icon",
                            modifier = Modifier
                                .size(48.dp)
                                .clickable {
                                    navController.navigate(ScreenRoutes.ProfileStatsScreen.name)
                                },
                            tint = Color(0xFF005b96)
                        )
                        Text(
                            text = userName.toString(),
                            modifier = Modifier.padding(2.dp),
                            style = MaterialTheme.typography.subtitle2,
                            color = Color(0xFF005b96),
                            fontSize = 16.sp,
                            maxLines = 1,
                            overflow = TextOverflow.Clip
                        )
                    }
                }
                Divider()
                ReadingNowSection(booksList = booksList, homeViewModel = homeViewModel) {
                    navController.navigate(ScreenRoutes.BookUpdateScreen.name + "/$it")
                }
                TitleSection(label = "Reading list:")
                BookListSection(booksList = booksList, homeViewModel = homeViewModel) {
                    navController.navigate(ScreenRoutes.BookUpdateScreen.name + "/$it")
                }
            }
        }
    }
}