package com.polware.bookcollection.data.models

data class RetailPrice(
    val amountInMicros: Long,
    val currencyCode: String
)