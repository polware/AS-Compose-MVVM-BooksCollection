package com.polware.bookcollection.data.models

data class ReadingModes(
    val image: Boolean,
    val text: Boolean
)