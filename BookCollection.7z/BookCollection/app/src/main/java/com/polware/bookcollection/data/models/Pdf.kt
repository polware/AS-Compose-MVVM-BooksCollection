package com.polware.bookcollection.data.models

data class Pdf(
    val acsTokenLink: String?,
    val isAvailable: Boolean
)