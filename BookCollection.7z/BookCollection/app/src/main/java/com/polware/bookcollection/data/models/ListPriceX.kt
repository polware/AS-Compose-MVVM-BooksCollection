package com.polware.bookcollection.data.models

data class ListPriceX(
    val amountInMicros: Long,
    val currencyCode: String
)