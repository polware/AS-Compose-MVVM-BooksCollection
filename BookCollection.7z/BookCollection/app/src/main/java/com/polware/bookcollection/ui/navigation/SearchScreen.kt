package com.polware.bookcollection.ui.navigation

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.CircularProgressIndicator
import androidx.compose.material.Scaffold
import androidx.compose.material.Surface
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import com.polware.bookcollection.ui.components.BookItem
import com.polware.bookcollection.ui.components.MainAppBar
import com.polware.bookcollection.ui.components.SearchContent
import com.polware.bookcollection.viewmodel.SearchViewModel

@Composable
fun SearchScreen(navController: NavController, viewModel: SearchViewModel) {
    val booksList = viewModel.booksList

    Scaffold(
        topBar = {
            MainAppBar(
                title = "Search Books",
                icon = Icons.Default.ArrowBack,
                navController = navController,
                showProfile = false
            ) {
                navController.navigate(ScreenRoutes.HomeScreen.name)
            }
        }        
    ) {
        Surface() {
            Column {
                SearchContent(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(15.dp)
                ) {
                    query ->
                    viewModel.searchBooks(query = query)
                }
                if (viewModel.isLoading) {
                    Row(
                        horizontalArrangement = Arrangement.Center,
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.fillMaxSize()
                    ) {
                        CircularProgressIndicator()
                    }
                }
                else {
                    Spacer(modifier = Modifier.height(15.dp))
                    LazyColumn(
                        modifier = Modifier.fillMaxSize(),
                        contentPadding = PaddingValues(15.dp)
                    ) {
                        items(items = booksList) {
                                book ->
                            BookItem(book = book, navController = navController)
                        }
                    }
                }
            }
        }
    }
}