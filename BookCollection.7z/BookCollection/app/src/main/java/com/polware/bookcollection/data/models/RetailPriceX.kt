package com.polware.bookcollection.data.models

data class RetailPriceX(
    val amount: Int,
    val currencyCode: String
)