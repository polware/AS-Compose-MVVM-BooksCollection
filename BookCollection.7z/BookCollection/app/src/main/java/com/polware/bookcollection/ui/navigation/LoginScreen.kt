package com.polware.bookcollection.ui.navigation

import android.util.Log
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.material.MaterialTheme
import androidx.compose.material.Surface
import androidx.compose.material.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import androidx.navigation.compose.rememberNavController
import com.polware.bookcollection.ui.components.UserDataForm
import com.polware.bookcollection.viewmodel.LoginViewModel
import androidx.lifecycle.viewmodel.compose.viewModel

@Composable
fun LoginScreen(navController: NavController, viewModel: LoginViewModel = viewModel()) {
    val enableLoginForm = rememberSaveable {
        mutableStateOf(true)
    }
    
    Surface(
        modifier = Modifier.fillMaxSize()
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Top
        ) {

            Spacer(modifier = Modifier.height(25.dp))
            Text(
                text = "Book Collection",
                style = MaterialTheme.typography.h3,
                color = Color(0xFFC99789)
            )
            Spacer(modifier = Modifier.height(30.dp))
            if (enableLoginForm.value) {
                UserDataForm(loading = false, isNewUser = false) {
                        email, password ->
                    Log.i("DataForm", "Inputs: $email $password")
                    viewModel.signIn(email = email, password = password) {
                        navController.navigate(ScreenRoutes.HomeScreen.name)
                    }
                }
            }
            else {
                UserDataForm(loading = false, isNewUser = true) {
                    email, password ->
                    viewModel.createUser(email = email, password = password) {
                        navController.navigate(ScreenRoutes.HomeScreen.name)
                    }
                }
            }
        }
        Spacer(modifier = Modifier.height(25.dp))
        Row(
            modifier = Modifier
                .padding(10.dp),
            horizontalArrangement = Arrangement.Center,
            verticalAlignment = Alignment.CenterVertically
        ) {
            val linkTextMessage = if (enableLoginForm.value) "Sign Up" else "Login"
            val descriptiveText = if (enableLoginForm.value) "Are you a new user?"
                                    else "Do you have an account?"
            Text(text = descriptiveText, style = MaterialTheme.typography.caption)
            Text(text = linkTextMessage,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colors.secondaryVariant,
                modifier = Modifier
                    .padding(start = 5.dp)
                    .clickable {
                        enableLoginForm.value = !enableLoginForm.value
                    }
            )
        }
    }
}

@Preview
@Composable
fun LoginScreenPreview() {
    LoginScreen(navController = rememberNavController())
}