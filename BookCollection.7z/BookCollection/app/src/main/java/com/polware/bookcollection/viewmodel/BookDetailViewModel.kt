package com.polware.bookcollection.viewmodel

import androidx.lifecycle.ViewModel
import com.polware.bookcollection.data.api.ResponseStatus
import com.polware.bookcollection.data.models.Item
import dagger.hilt.android.lifecycle.HiltViewModel
import javax.inject.Inject

@HiltViewModel
class BookDetailViewModel @Inject constructor(private val repository: BookRepository): ViewModel() {

    suspend fun getBookDetails(bookId: String): ResponseStatus<Item> {
        return repository.getBookDetails(bookId = bookId)
    }

}