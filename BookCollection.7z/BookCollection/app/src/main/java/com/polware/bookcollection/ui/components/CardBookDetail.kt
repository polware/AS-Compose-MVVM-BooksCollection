package com.polware.bookcollection.ui.components

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.Card
import androidx.compose.material.MaterialTheme
import androidx.compose.material.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import coil.compose.AsyncImage
import com.polware.bookcollection.data.firebase.FirestoreBook

@Composable
fun CardBookDetail(book: FirestoreBook?, onClickDetail: () -> Unit) {
    Card(
        modifier = Modifier
            .padding(start = 4.dp, end = 4.dp, top = 4.dp, bottom = 8.dp)
            .clip(RoundedCornerShape(20.dp))
            .clickable {

            },
        elevation = 6.dp
    ) {
        Row(
            horizontalArrangement = Arrangement.Start,
            verticalAlignment = Alignment.CenterVertically
        ) {
            AsyncImage(
                model = book?.imageUrl,
                contentScale = ContentScale.Crop,
                contentDescription = "Book image",
                modifier = Modifier
                    .width(120.dp)
                    .height(120.dp)
                    .padding(6.dp)
                    .clip(
                        RoundedCornerShape(
                            topStart = 0.dp, topEnd = 0.dp,
                            bottomStart = 0.dp, bottomEnd = 40.dp
                        )
                    )
            )
            Column {
                Text(
                    text =  book?.title.toString(),
                    textAlign = TextAlign.Start,
                    style = MaterialTheme.typography.subtitle2,
                    modifier = Modifier
                        .padding(start = 8.dp, end = 20.dp),
                    fontWeight = FontWeight.Bold,
                    maxLines = 2,
                    overflow = TextOverflow.Ellipsis
                )
                Text(
                    text = "Author(s): ${book?.authors}",
                    textAlign = TextAlign.Start,
                    maxLines = 2,
                    overflow = TextOverflow.Ellipsis,
                    style = MaterialTheme.typography.caption,
                    modifier = Modifier
                        .padding(start = 8.dp, end = 8.dp, top = 1.dp)
                )
                Text(
                    text = "Published: ${book?.publishedDate}",
                    style = MaterialTheme.typography.caption,
                    modifier = Modifier.padding(start = 8.dp, end = 8.dp, top = 1.dp)
                )
            }
        }
    }
}