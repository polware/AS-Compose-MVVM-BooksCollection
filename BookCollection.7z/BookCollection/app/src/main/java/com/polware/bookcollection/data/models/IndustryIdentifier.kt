package com.polware.bookcollection.data.models

data class IndustryIdentifier(
    val identifier: String,
    val type: String
)