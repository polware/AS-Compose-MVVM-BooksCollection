package com.polware.bookcollection.data.api

import com.polware.bookcollection.data.models.Book
import com.polware.bookcollection.data.models.Item
import retrofit2.http.GET
import retrofit2.http.Path
import retrofit2.http.Query
import javax.inject.Singleton

@Singleton
interface GoogleApi {

    @GET("volumes")
    suspend fun getAllBooks(@Query("q") query: String): Book

    @GET("volumes/{bookId}")
    suspend fun getBookDetails(@Path("bookId") bookId: String): Item

}