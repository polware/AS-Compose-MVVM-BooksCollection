package com.polware.bookcollection.ui.navigation

import android.os.Build
import androidx.annotation.RequiresApi
import androidx.compose.runtime.Composable
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import com.polware.bookcollection.viewmodel.BookDetailViewModel
import com.polware.bookcollection.viewmodel.HomeViewModel
import com.polware.bookcollection.viewmodel.SearchViewModel

@RequiresApi(Build.VERSION_CODES.N)
@Composable
fun AppNavigation() {
    val navController = rememberNavController()
    NavHost(navController = navController, startDestination = ScreenRoutes.SplashScreen.name) {

        composable(ScreenRoutes.SplashScreen.name) {
            SplashScreen(navController = navController)
        }

        composable(ScreenRoutes.LoginScreen.name) {
            LoginScreen(navController = navController)
        }

        composable(ScreenRoutes.HomeScreen.name) {
            val homeViewModel = hiltViewModel<HomeViewModel>()
            HomeScreen(navController = navController, homeViewModel = homeViewModel)
        }

        composable(ScreenRoutes.ProfileStatsScreen.name) {
            val homeViewModel = hiltViewModel<HomeViewModel>()
            ProfileStatsScreen(navController = navController, homeViewModel = homeViewModel)
        }

        composable(ScreenRoutes.SearchScreen.name) {
            val searchViewModel = hiltViewModel<SearchViewModel>()
            SearchScreen(navController = navController, viewModel = searchViewModel)
        }

        val bookInfo = ScreenRoutes.BookDetailsScreen.name
        composable("$bookInfo/{bookId}",
            arguments = listOf(navArgument("bookId") {
                type = NavType.StringType
            }
            )) {
            navBackStackEntry ->
            val bookDetailViewModel = hiltViewModel<BookDetailViewModel>()
            navBackStackEntry.arguments?.getString("bookId").let {
                BookDetailsScreen(navController = navController,
                    bookId = it.toString(), bookDetailViewModel = bookDetailViewModel)
            }
        }

        val updateBook = ScreenRoutes.BookUpdateScreen.name
        composable("$updateBook/{bookDatabaseId}",
            arguments = listOf(navArgument("bookDatabaseId") {
                type = NavType.StringType
            }
            )) {
            navBackStackEntry ->
            val homeViewModel = hiltViewModel<HomeViewModel>()
            navBackStackEntry.arguments?.getString("bookDatabaseId").let {
                BookUpdateScreen(navController = navController,
                    bookDatabaseId = it.toString(), homeViewModel = homeViewModel)
            }
        }

    }
}