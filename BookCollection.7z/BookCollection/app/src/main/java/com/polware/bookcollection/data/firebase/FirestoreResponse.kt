package com.polware.bookcollection.data.firebase

data class FirestoreResponse<T, Boolean, E: Exception?>(
    var data: T? = null,
    var loading: Boolean? = null,
    var exception: E? = null
)
