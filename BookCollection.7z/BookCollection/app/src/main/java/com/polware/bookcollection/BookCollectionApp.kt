package com.polware.bookcollection

import android.app.Application
import dagger.hilt.android.HiltAndroidApp

@HiltAndroidApp
class BookCollectionApp: Application() {

}