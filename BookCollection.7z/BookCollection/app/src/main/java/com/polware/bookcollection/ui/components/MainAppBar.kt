package com.polware.bookcollection.ui.components

import androidx.compose.foundation.Image
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.Icon
import androidx.compose.material.IconButton
import androidx.compose.material.Text
import androidx.compose.material.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import com.google.firebase.auth.FirebaseAuth
import com.polware.bookcollection.R
import com.polware.bookcollection.ui.navigation.ScreenRoutes

@Composable
fun MainAppBar(title: String, icon: ImageVector? = null, showProfile: Boolean = true,
               navController: NavController, onBackPressed: () -> Unit = {} ) {
    TopAppBar(
        title = {
            Row(verticalAlignment = Alignment.CenterVertically) {
                if (showProfile) {
                    Image(
                        painter = painterResource(id = R.drawable.ebook_icon),
                        contentDescription = "Icon",
                        modifier = Modifier
                            .clip(RoundedCornerShape(10.dp))
                    )
                }
                if (icon != null) {
                    Icon(
                        imageVector = icon,
                        contentDescription = "ArrowBack icon",
                        tint = Color(0xFFC99789),
                        modifier = Modifier.clickable {
                            onBackPressed.invoke()
                        }
                    )
                }
                Text(
                    text = title,
                    color = Color(0xFFC99789),
                    style = TextStyle(fontWeight = FontWeight.Bold, fontSize = 22.sp),
                    modifier = Modifier.padding(start = 10.dp)
                )
                Spacer(modifier = Modifier.width(100.dp))
            }
        },
        actions = {
            if (showProfile) {
                IconButton(
                    onClick = {
                        FirebaseAuth.getInstance().signOut().run {
                            navController.navigate(ScreenRoutes.LoginScreen.name)
                        }
                    }
                ) {
                    Icon(
                        painter = painterResource(id = R.drawable.ic_sign_out_icon),
                        contentDescription = "Sign out icon",
                        tint = Color.Red.copy(alpha = 0.6f)
                    )

                }
            }
        },
        backgroundColor = Color.Transparent,
        elevation = 0.dp
    )

}