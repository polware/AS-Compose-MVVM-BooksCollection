package com.polware.bookcollection.viewmodel

import android.util.Log
import androidx.compose.runtime.MutableState
import androidx.compose.runtime.mutableStateOf
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.polware.bookcollection.data.firebase.FirestoreBook
import com.polware.bookcollection.data.firebase.FirestoreResponse
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class HomeViewModel @Inject constructor(private val repository: FirestoreRepository): ViewModel() {

    val fireStoreData: MutableState<FirestoreResponse<List<FirestoreBook>, Boolean, Exception>>
        = mutableStateOf(FirestoreResponse(listOf(), true, Exception("")))

    init {
        getBooksFromDatabase()
    }

    private fun getBooksFromDatabase() {
        viewModelScope.launch {
            fireStoreData.value.loading = true
            fireStoreData.value = repository.getBooksFromDB()
            if (!fireStoreData.value.data.isNullOrEmpty())
                fireStoreData.value.loading = false
        }
        Log.d("Firestore", "Books: ${fireStoreData.value.data?.toList().toString()}")
    }

}