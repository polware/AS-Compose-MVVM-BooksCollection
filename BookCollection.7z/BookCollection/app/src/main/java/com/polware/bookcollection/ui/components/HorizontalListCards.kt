package com.polware.bookcollection.ui.components

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.Card
import androidx.compose.material.Icon
import androidx.compose.material.MaterialTheme
import androidx.compose.material.Text
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.FavoriteBorder
import androidx.compose.runtime.Composable
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import coil.compose.AsyncImage
import com.polware.bookcollection.data.firebase.FirestoreBook

@Composable
fun HorizontalListCards(book: FirestoreBook, onClickDetails: (String) -> Unit
) {
    val context = LocalContext.current
    val resources = context.resources
    val displayMetrics = resources.displayMetrics
    val screenWidth = displayMetrics.widthPixels / displayMetrics.density
    val spacing = 10.dp
    val isStartedReading = remember {
        mutableStateOf(false)
    }
    isStartedReading.value = book.startedReading != null

    Card(
        shape = RoundedCornerShape(20.dp),
        backgroundColor = Color(0xFFe7eff6),
        elevation = 6.dp,
        modifier = Modifier
            .padding(15.dp)
            .width(200.dp)
            .height(240.dp)
            .clickable {
                onClickDetails.invoke(book.googleBookId.toString())
            }
    ) {
        Column(
            modifier = Modifier.width(screenWidth.dp - spacing * 2),
            horizontalAlignment = Alignment.Start
        ) {
            Row(
                horizontalArrangement = Arrangement.Center

            ) {

                AsyncImage(
                    model = book.imageUrl,
                    contentScale = ContentScale.Crop,
                    contentDescription = "Book image",
                    modifier = Modifier
                        .width(140.dp)
                        .height(140.dp)
                        .padding(10.dp)
                )
                Spacer(modifier = Modifier.width(15.dp))
                Column(
                    modifier = Modifier.padding(top = 25.dp),
                    verticalArrangement = Arrangement.Center,
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Icon(
                        imageVector = Icons.Rounded.FavoriteBorder,
                        contentDescription = "Favorite icon",
                        modifier = Modifier.padding(bottom = 1.dp)
                    )
                    BookRating(score = book.rating!!)
                }
            }

            Text(
                text = book.title.toString(),
                modifier = Modifier.padding(start = 10.dp, top = 5.dp),
                fontWeight = FontWeight.Bold,
                maxLines = 2,
                overflow = TextOverflow.Ellipsis
            )
            Text(
                text = book.authors.toString(),
                modifier = Modifier.padding(start = 10.dp, top = 5.dp),
                style = MaterialTheme.typography.caption
            )
            Row(
                modifier = Modifier.fillMaxSize(),
                horizontalArrangement = Arrangement.End,
                verticalAlignment = Alignment.Bottom
                ) {
                RoundedButton(
                    label = if (isStartedReading.value) "Reading" else "Not started",
                    radius = 50
                )
            }
        }
    }
}