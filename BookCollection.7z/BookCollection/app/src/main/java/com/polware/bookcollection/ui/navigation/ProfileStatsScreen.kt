package com.polware.bookcollection.ui.navigation

import android.os.Build
import androidx.annotation.RequiresApi
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.sharp.Person
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import com.google.firebase.auth.FirebaseAuth
import com.polware.bookcollection.data.firebase.FirestoreBook
import com.polware.bookcollection.ui.components.BookRowStats
import com.polware.bookcollection.ui.components.MainAppBar
import com.polware.bookcollection.viewmodel.HomeViewModel
import java.util.*

@RequiresApi(Build.VERSION_CODES.N)
@Composable
fun ProfileStatsScreen(navController: NavController, homeViewModel: HomeViewModel) {
    val booksList: List<FirestoreBook>
    val currentUser = FirebaseAuth.getInstance().currentUser

    booksList = if (!homeViewModel.fireStoreData.value.data.isNullOrEmpty()) {
        homeViewModel.fireStoreData.value.data!!.filter {
            book ->
            (book.userId == currentUser?.uid)
        }
    }
    else {
        emptyList()
    }

    val readingBooks = booksList.filter {
            book ->
        (book.startedReading != null && book.finishedReading == null)
    }

    val finishedBooksList = if (!homeViewModel.fireStoreData.value.data.isNullOrEmpty()) {
        booksList.filter {
                book ->
                (book.userId == currentUser?.uid) && (book.finishedReading != null)
        }
    }
    else {
        emptyList()
    }

    Scaffold(
        topBar = {
            MainAppBar(
                title = "Profile Stats",
                icon = Icons.Default.ArrowBack,
                showProfile = false,
                navController = navController) {
                navController.popBackStack()
            }
        }
    ) {
        Surface() {
            //Show the books that user has been read
            Column {
                Row(
                    modifier = Modifier.padding(15.dp).fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        imageVector = Icons.Sharp.Person,
                        contentDescription = "Profile icon",
                        modifier = Modifier.size(32.dp)
                    )
                    Text(
                        text = "Welcome, ${currentUser?.email.toString()
                            .split("@")[0].uppercase(Locale.getDefault())}",
                        fontWeight = FontWeight.Bold,
                        color = Color(0xFF005b96),
                        modifier = Modifier.padding(start = 4.dp)
                    )
                }
                // Summary of statistics
                Card(
                    modifier = Modifier.fillMaxWidth().padding(4.dp),
                    shape = CircleShape,
                    elevation = 6.dp
                ) {
                    Column(
                        modifier = Modifier.padding(top = 8.dp, bottom = 8.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Text(
                            text = "Your Stats",
                            style = MaterialTheme.typography.h5,
                            fontWeight = FontWeight.Bold,
                            color = Color(0xFF005b96)
                        )
                        Divider()
                        Text(
                            text = "You're reading: ${readingBooks.size} books",
                            style = MaterialTheme.typography.subtitle2,
                        )
                        Text(
                            text = "You've read: ${finishedBooksList.size} books",
                            style = MaterialTheme.typography.subtitle2,
                        )
                    }
                }
                Divider(modifier = Modifier.padding(top = 20.dp))

                if (homeViewModel.fireStoreData.value.loading == true) {
                    Row(modifier = Modifier
                        .fillMaxSize(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.Center
                    ) {
                        CircularProgressIndicator()
                    }
                }
                else {
                    LazyColumn(modifier = Modifier
                        .fillMaxWidth()
                        .fillMaxHeight(),
                        contentPadding = PaddingValues(15.dp)
                    ){
                        // Filter finished books
                        val readBooks: List<FirestoreBook> = if (!homeViewModel
                                .fireStoreData.value.data.isNullOrEmpty()) {
                            homeViewModel.fireStoreData.value.data!!.filter {
                                    book ->
                                    (book.userId == currentUser?.uid) && (book.finishedReading != null)
                            }
                        }
                        else {
                            emptyList()
                        }
                        items(items = readBooks) {book ->
                            BookRowStats(book = book )
                        }
                    }
                }
            }
        }
    }
}