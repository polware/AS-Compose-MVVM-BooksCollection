package com.polware.bookcollection.viewmodel

import android.util.Log
import com.polware.bookcollection.data.api.GoogleApi
import com.polware.bookcollection.data.api.ResponseStatus
import com.polware.bookcollection.data.models.Item
import javax.inject.Inject

class BookRepository @Inject constructor(private val apiService: GoogleApi) {

    suspend fun getBooks(searchQuery: String): ResponseStatus<List<Item>> {
        return try {
            ResponseStatus.Loading(data = true)
            val itemList = apiService.getAllBooks(searchQuery).items
            if (itemList.isNotEmpty())
                ResponseStatus.Loading(data = false)
            ResponseStatus.Success(data = itemList)

        } catch (exception: Exception) {
            Log.e("ApiResponse", "Exception: ${exception.message}")
            ResponseStatus.Error(message = exception.message.toString())
        }
    }

    suspend fun getBookDetails(bookId: String): ResponseStatus<Item> {
        val response = try {
            ResponseStatus.Loading(data = true)
            apiService.getBookDetails(bookId)
        } catch (exception: Exception){
            return ResponseStatus.Error(message = "An error has occurred ${exception.message.toString()}")
        }
        ResponseStatus.Loading(data = false)
        return ResponseStatus.Success(data = response)
    }

}