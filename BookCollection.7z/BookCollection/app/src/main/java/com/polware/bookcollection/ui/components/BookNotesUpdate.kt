package com.polware.bookcollection.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.runtime.Composable
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.ExperimentalComposeUiApi
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalSoftwareKeyboardController
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp

@OptIn(ExperimentalComposeUiApi::class)
@Composable
fun BookNotesUpdate(notes: String, onFinish: (String) -> Unit) {
    val keyboardController = LocalSoftwareKeyboardController.current
    val textFieldValue = rememberSaveable {
        mutableStateOf("")
    }
    //textFieldValue.value = notes
    val valid = remember(textFieldValue.value) { textFieldValue.value.trim().isNotEmpty() }

    Column {
        InputTextField(
            modifier = Modifier
                .height(140.dp)
                .padding(3.dp)
                .background(Color.White, CircleShape)
                .padding(horizontal = 20.dp, vertical = 12.dp),
            valueState = textFieldValue,
            labelId = "Notes about the book",
            enabled = true,
            isSingleLine = false,
            keyboardType = KeyboardType.Text,
            onAction = KeyboardActions {
                if (!valid)
                    return@KeyboardActions
                onFinish(textFieldValue.value.trim())
                keyboardController?.hide()
            }
        )
    }
}