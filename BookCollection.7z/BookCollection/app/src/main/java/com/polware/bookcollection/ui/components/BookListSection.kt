package com.polware.bookcollection.ui.components

import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.material.CircularProgressIndicator
import androidx.compose.material.Surface
import androidx.compose.material.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.polware.bookcollection.data.firebase.FirestoreBook
import com.polware.bookcollection.viewmodel.HomeViewModel

@Composable
fun BookListSection(booksList: List<FirestoreBook>, homeViewModel: HomeViewModel,
                    onCardClick: (String) -> Unit) {
    val scrollState = rememberScrollState()
    val newBooksAdded = booksList.filter {
        book ->
        book.startedReading == null && book.finishedReading == null
    }

    if (homeViewModel.fireStoreData.value.loading == true) {
        Row(modifier = Modifier
            .fillMaxWidth()
            .heightIn(240.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.Center
        ) {
            CircularProgressIndicator()
        }
    }
    else {
        if (newBooksAdded.isNullOrEmpty()) {
            Surface(
                modifier = Modifier.padding(top = 60.dp).fillMaxWidth().heightIn(200.dp)
            ) {
                Text(
                    text = "There are no books added to the collection.",
                    style = TextStyle(
                        color = Color.Red.copy(alpha = 0.6f),
                        textAlign = TextAlign.Center,
                        fontWeight = FontWeight.Bold,
                        fontSize = 16.sp
                    )
                )
            }
        }
        else {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .heightIn(280.dp)
                    .horizontalScroll(scrollState)
            ) {
                for (book in newBooksAdded) {
                    HorizontalListCards(book) {
                        onCardClick.invoke(it)
                    }
                }
            }
        }
    }

}