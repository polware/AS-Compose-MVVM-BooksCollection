package com.polware.bookcollection.data.models

data class SearchInfo(
    val textSnippet: String
)