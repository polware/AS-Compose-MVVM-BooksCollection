package com.polware.bookcollection.viewmodel

import android.util.Log
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.polware.bookcollection.data.api.ResponseStatus
import com.polware.bookcollection.data.models.Item
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class SearchViewModel @Inject constructor(private val repository: BookRepository): ViewModel() {
    var booksList: List<Item> by mutableStateOf(listOf())
    var isLoading: Boolean by mutableStateOf(true)

    init {
        loadBooks()
    }

    private fun loadBooks() {
        searchBooks("flutter")
    }

    fun searchBooks(query: String) {
        viewModelScope.launch(Dispatchers.Default) {
            if (query.isEmpty()){
                return@launch
            }
            try {
                when(val response = repository.getBooks(query)) {
                    is ResponseStatus.Success -> {
                        booksList = response.data!!
                        Log.i("ApiResponse", "Result: ${response.data}")
                        if (booksList.isNotEmpty())
                            isLoading = false
                    }
                    is ResponseStatus.Error -> {
                        isLoading = false
                        Log.e("SearchBooks", "Error: Failed getting books", )
                    }
                    else -> {
                        isLoading = false
                    }
                }
            } catch (exception: Exception){
                isLoading = false
                Log.d("SearchBooks", "Exception: ${exception.message.toString()}")
            }
        }
    }

}